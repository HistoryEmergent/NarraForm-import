-- Remove duplicate "Imported Content" episode
DELETE FROM episodes WHERE id = '25c716e1-e675-4b9a-8b21-a0d4a85a4e35';